package com.nucleus.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nucleus.book.Book;

@Repository
public class BookDAOImpl implements BookDAO
{
	@Autowired
    JdbcTemplate jdbcTemplate;
	@Override
	public void save(Book book) 
	{
		Object[] values={book.getBookId(),book.getBookName(),book.getAuthor(),book.getPrice()};
		jdbcTemplate.update("insert into bookbook values(?,?,?,?)",values);
		
	}
	
	@Override
	public void delete(String bookId)
	{
	
		jdbcTemplate.update("delete from BookBook where bookId=?", bookId);
	}
	@Override
	public void view( Book book)
	{  String bookId=book.getBookId();
	
		jdbcTemplate.update("select * from BookBook where bookId=?", bookId);
		
	}

}
