package com.nucleus.DAO;

import org.springframework.stereotype.Repository;

import com.nucleus.book.Book;
@Repository
public interface BookDAO 
{

	public void save(Book book);

	public void delete(String bookId);

	public void view(Book book);
	
	
}
