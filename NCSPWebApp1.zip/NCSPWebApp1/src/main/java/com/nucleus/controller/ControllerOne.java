package com.nucleus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.DAO.BookDAO;
import com.nucleus.book.Book;

@Controller
public class ControllerOne 
{   
	
	@Autowired
	BookDAO bookDAO;
//***********************************************************************************	
	
	
	@RequestMapping("/link1")
	public ModelAndView handler1()
	{
		return new ModelAndView("success");
	}
	
	
//************************************************************************************	
	
	
	@RequestMapping("/BookReg")
	public String handler2(Book book)
	{
		return "BookRegistration";
	}
	
	
	
	
	@RequestMapping("/booksubmit")
	public ModelAndView handler3(Book book)
	{
		bookDAO.save(book);
		return new ModelAndView("success");
	}
	
	
//*******************************************************************************
	
	
	@RequestMapping("/DeleteBook")
	public ModelAndView handler4(Book book)
	{
		return new ModelAndView("dltbook1");
	}
	
	
	@RequestMapping("/bookdelete1")
	public ModelAndView handler5(@RequestParam("bookId")String bookId)
	{
		bookDAO.delete(bookId);
		return new ModelAndView("dlt");
	}
	

	
	
//********************************************************************************
	
	
	@RequestMapping("/view")
	public ModelAndView handler6(Book book)
	{
		return new ModelAndView( "view1");
	}
	
	
	@RequestMapping("/viewbook")
	public ModelAndView handler7(Book book)
	{
		bookDAO.view(book);
		return new ModelAndView("success");
	}
	
	
//********************************************************************************
	
	
	@RequestMapping("/UpdateBook")
	public String handler(Book book)
	{
		return "BookRegistration";
	}
	
	
	
//********************************************************************************
	
	
	
	
	
	
	
}
